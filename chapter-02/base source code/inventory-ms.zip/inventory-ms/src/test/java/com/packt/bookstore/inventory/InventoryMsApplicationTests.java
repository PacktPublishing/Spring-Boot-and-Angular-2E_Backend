package com.packt.bookstore.inventory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventoryMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
